# internsample > 2025-07-18 3:05pm
https://universe.roboflow.com/practise-fvgr4/internsample

Provided by a Roboflow user
License: CC BY 4.0

